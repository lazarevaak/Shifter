import UIKit
import CoreData

// MARK: - Модели Use Case

enum AvatarSelection {
    enum SaveAvatar {
        struct Request {
            let selectedImage: UIImage?
            let selectedIconIndex: Int?
        }
        struct Response {
            let success: Bool
            let message: String?
        }
        struct ViewModel {
            let displayMessage: String
        }
    }
    
    enum FetchAvatarIcons {
        struct Request { }
        struct Response {
            let icons: [String]
        }
        struct ViewModel {
            let icons: [String]
        }
    }
}

// MARK: - Протокол бизнес-логики

protocol AvatarSelectionBusinessLogic {
    func saveAvatar(request: AvatarSelection.SaveAvatar.Request)
    func fetchAvatarIcons(request: AvatarSelection.FetchAvatarIcons.Request)
}

// MARK: - Протокол презентационной логики

protocol AvatarSelectionPresentationLogic: AnyObject {
    func presentSaveAvatar(response: AvatarSelection.SaveAvatar.Response)
    func presentAvatarIcons(response: AvatarSelection.FetchAvatarIcons.Response)
}

// MARK: - Протокол для навигации

protocol AvatarSelectionRoutingLogic {
    func dismiss()
}

// MARK: - Interactor

final class AvatarSelectionInteractor: AvatarSelectionBusinessLogic {
    var presenter: AvatarSelectionPresentationLogic?
    private let user: User
    private let context: NSManagedObjectContext
    
    init(user: User, context: NSManagedObjectContext) {
        self.user = user
        self.context = context
    }
    
    func saveAvatar(request: AvatarSelection.SaveAvatar.Request) {
        var selectedImage: UIImage?
        if let index = request.selectedIconIndex {
            let iconName = AvatarSelectionConstants.avatarIcons[index]
            selectedImage = UIImage(named: iconName)
        }
        if let image = request.selectedImage {
            selectedImage = image
        }
        
        guard let finalImage = selectedImage,
              let data = finalImage.jpegData(compressionQuality: 0.8) else {
            let response = AvatarSelection.SaveAvatar.Response(success: false, message: "Выберите аватарку или сделайте фото")
            presenter?.presentSaveAvatar(response: response)
            return
        }
        
        user.avatarData = data
        do {
            try context.save()
            let response = AvatarSelection.SaveAvatar.Response(success: true, message: "Аватар успешно сохранён")
            presenter?.presentSaveAvatar(response: response)
        } catch {
            let response = AvatarSelection.SaveAvatar.Response(success: false, message: "Ошибка сохранения аватара: \(error)")
            presenter?.presentSaveAvatar(response: response)
        }
    }
    
    func fetchAvatarIcons(request: AvatarSelection.FetchAvatarIcons.Request) {
        let response = AvatarSelection.FetchAvatarIcons.Response(icons: AvatarSelectionConstants.avatarIcons)
        presenter?.presentAvatarIcons(response: response)
    }
}

