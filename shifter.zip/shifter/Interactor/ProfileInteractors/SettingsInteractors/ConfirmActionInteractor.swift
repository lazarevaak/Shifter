import UIKit

// MARK: - Models
enum ConfirmActionModels {
    enum Confirm {
        struct Request {
            let password: String
        }
        struct Response {
            let isValid: Bool
            let errorMessage: String?
        }
        struct ViewModel {
            let success: Bool
            let message: String
        }
    }
}

// MARK: - Business Logic
protocol ConfirmActionBusinessLogic {
    func confirmAction(request: ConfirmActionModels.Confirm.Request)
}

final class ConfirmActionInteractor: ConfirmActionBusinessLogic {
    var presenter: ConfirmActionPresentationLogic?
    private let user: User
    
    init(user: User) {
        self.user = user
    }
    
    func confirmAction(request: ConfirmActionModels.Confirm.Request) {
        let isValid = (request.password == user.password)
        let errorMessage = isValid ? nil : "incorrect_password".localized
        let response = ConfirmActionModels.Confirm.Response(isValid: isValid,
                                                            errorMessage: errorMessage)
        presenter?.presentConfirmAction(response: response)
    }
}
