import Foundation

enum EditLanguageModels {
    enum UpdateLanguage {
        struct Request {
            let newLanguage: String
        }
        struct Response {
            let success: Bool
            let message: String?
        }
        struct ViewModel {
            let success: Bool
            let message: String
        }
    }
}

// MARK: - Business Logic
protocol EditLanguageBusinessLogic {
    func updateLanguage(request: EditLanguageModels.UpdateLanguage.Request)
}

final class EditLanguageInteractor: EditLanguageBusinessLogic {
    var presenter: EditLanguagePresentationLogic?
    
    func updateLanguage(request: EditLanguageModels.UpdateLanguage.Request) {
        if request.newLanguage.isEmpty {
            // Если выбор пустой, выдаём ошибку
            let response = EditLanguageModels.UpdateLanguage.Response(success: false,
                message: "error_select_language".localized)
            presenter?.presentUpdateLanguage(response: response)
        } else {
            // Иначе – успешное обновление
            let response = EditLanguageModels.UpdateLanguage.Response(success: true,
                message: "language_update_success".localized)
            presenter?.presentUpdateLanguage(response: response)
        }
    }
}
