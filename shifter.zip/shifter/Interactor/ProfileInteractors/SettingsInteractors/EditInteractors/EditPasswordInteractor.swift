import Foundation

enum EditPasswordModels {
    enum UpdatePassword {
        struct Request {
            let newPassword: String
        }
        struct Response {
            let success: Bool
            let message: String?
        }
        struct ViewModel {
            let success: Bool
            let message: String
        }
    }
}

// MARK: - Business Logic
protocol EditPasswordBusinessLogic {
    func updatePassword(request: EditPasswordModels.UpdatePassword.Request)
}

final class EditPasswordInteractor: EditPasswordBusinessLogic {
    var presenter: EditPasswordPresentationLogic?
    private let userId: String
    private let currentPassword: String
    
    init(userId: String, currentPassword: String) {
        self.userId = userId
        self.currentPassword = currentPassword
    }
    
    func updatePassword(request: EditPasswordModels.UpdatePassword.Request) {
        UserDataManager.shared.updatePassword(for: userId, newPassword: request.newPassword) { [weak self] success in
            guard let self = self else { return }
            let response: EditPasswordModels.UpdatePassword.Response
            if success {
                // Используем локализованную строку для успешного обновления пароля
                response = EditPasswordModels.UpdatePassword.Response(success: true,
                                                                      message: "password_update_success".localized)
            } else {
                // Используем локализованную строку для ошибки обновления пароля
                response = EditPasswordModels.UpdatePassword.Response(success: false,
                                                                      message: "password_update_failed".localized)
            }
            DispatchQueue.main.async {
                self.presenter?.presentUpdatePassword(response: response)
            }
        }
    }
}
