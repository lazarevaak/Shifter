import Foundation

enum EditUsernameModels {
    enum UpdateUsername {
        struct Request {
            let newName: String
        }
        struct Response {
            let success: Bool
            let message: String?
        }
        struct ViewModel {
            let success: Bool
            let message: String
        }
    }
}

import Foundation

// MARK: - Business Logic
protocol EditUsernameBusinessLogic {
    func updateUsername(request: EditUsernameModels.UpdateUsername.Request)
}

final class EditUsernameInteractor: EditUsernameBusinessLogic {
    var presenter: EditUsernamePresentationLogic?
    private let userId: String
    private let currentUsername: String
    
    init(userId: String, currentUsername: String) {
        self.userId = userId
        self.currentUsername = currentUsername
    }
    
    func updateUsername(request: EditUsernameModels.UpdateUsername.Request) {
        // Здесь вызывается метод обновления имени пользователя через DataManager.
        // В данном примере используется UserDataManager.shared.updateUsername(...)
        UserDataManager.shared.updateUsername(for: userId, newName: request.newName) { [weak self] success in
            guard let self = self else { return }
            let response: EditUsernameModels.UpdateUsername.Response
            if success {
                response = EditUsernameModels.UpdateUsername.Response(success: true,
                                                                      message: "username_update_success".localized)
            } else {
                response = EditUsernameModels.UpdateUsername.Response(success: false,
                                                                      message: "username_update_failed".localized)
            }
            DispatchQueue.main.async {
                self.presenter?.presentUpdateUsername(response: response)
            }
        }
    }
}

