import UIKit
import CoreData
import Foundation
import OSLog

// MARK: - Module: EditCard
enum EditCard {
    enum UpdateCard {
        struct Request {
            let question: String
            let answer: String
        }
        
        struct Response {
            let card: Card
        }
        
        struct ViewModel {
            let card: Card
        }
    }
}

// MARK: - Бизнес-логика (Interactor)
protocol EditCardBusinessLogic {
    func updateCard(request: EditCard.UpdateCard.Request)
}

class EditCardInteractor: EditCardBusinessLogic {
    var presenter: EditCardPresentationLogic?
    
    /// Редактируемый объект Core Data
    var card: Card

    init(card: Card) {
        self.card = card
    }
    
    func updateCard(request: EditCard.UpdateCard.Request) {
        // Присваиваем новые значения полям question/answer
        card.question = request.question
        card.answer = request.answer
        
        // Сохраняем изменения в контексте Core Data
        guard let context = card.managedObjectContext else {
            os_log("ManagedObjectContext is nil. Убедитесь, что объект card добавлен в Core Data Stack.",
                   log: OSLog.default, type: .error)
            return
        }
        
        do {
            try context.save()
            os_log("Card saved successfully", log: OSLog.default, type: .info)
        } catch {
            os_log("Error saving card: %{public}@", log: OSLog.default, type: .error, error.localizedDescription)
        }
        
        // Формируем Response и передаем в Presenter
        let response = EditCard.UpdateCard.Response(card: card)
        presenter?.presentUpdatedCard(response: response)
    }
}
