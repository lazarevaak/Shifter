import UIKit
import CoreData
import Foundation

enum TestModels {
    
    // MARK: - Test Request / Response / ViewModel
    
    struct TestRequest { }
    
    struct TestResponse {
        let question: String?
        let currentIndex: Int
        let totalCards: Int
        let progress: Float
        let isTestCompleted: Bool
    }
    
    struct TestViewModel {
        let questionText: String?
        let currentIndexText: String
        let totalCardsText: String
        let progress: Float
        let isTestCompleted: Bool
    }
    
    // MARK: - Check Answer Request / Response / ViewModel
    
    struct CheckAnswerRequest {
        let userAnswer: String
    }
    
    struct CheckAnswerResponse {
        let resultMessage: String
        let correctAnswers: Int
        let incorrectAnswers: Int
        let totalCards: Int
        let isTestCompleted: Bool
    }
    
    struct CheckAnswerViewModel {
        let alertTitle: String
        let correctAnswers: Int
        let incorrectAnswers: Int
        let totalCards: Int
        let isTestCompleted: Bool
    }
}


protocol TestBusinessLogic: AnyObject {
    func viewDidLoad(request: TestModels.TestRequest)
    func checkAnswer(request: TestModels.CheckAnswerRequest)
}

final class TestInteractor: TestBusinessLogic {
    
    var presenter: TestPresentationLogic?
    var cardSet: CardSet?
    var cards: [Card] = []
    var currentIndex = 0
    var correctAnswers = 0
    var incorrectAnswers = 0
    
    init(cardSet: CardSet?) {
        self.cardSet = cardSet
        if let set = cardSet, let cardObjects = set.cards?.allObjects as? [Card] {
            cards = cardObjects.sorted { ($0.question ?? "") < ($1.question ?? "") }
        }
    }
    
    func viewDidLoad(request: TestModels.TestRequest) {
        if currentIndex < cards.count {
            let card = cards[currentIndex]
            let response = TestModels.TestResponse(
                question: card.question,
                currentIndex: currentIndex,
                totalCards: cards.count,
                progress: Float(currentIndex + 1) / Float(cards.count),
                isTestCompleted: false
            )
            presenter?.presentTest(response: response)
        } else {
            let response = TestModels.TestResponse(
                question: nil,
                currentIndex: currentIndex,
                totalCards: cards.count,
                progress: 1.0,
                isTestCompleted: true
            )
            presenter?.presentTest(response: response)
        }
    }
    
    func checkAnswer(request: TestModels.CheckAnswerRequest) {
        guard currentIndex < cards.count else { return }
        let card = cards[currentIndex]
        
        let userAnswer = request.userAnswer.trimmingCharacters(in: .whitespacesAndNewlines)
        let correctAnswer = card.answer?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        
        var resultMessage = ""
        if userAnswer.caseInsensitiveCompare(correctAnswer) == .orderedSame {
            resultMessage = "Correct!"
            correctAnswers += 1
            card.isLearned = true
        } else {
            resultMessage = "Incorrect.\nThe correct answer is: \(correctAnswer)"
            card.isLearned = false
            incorrectAnswers += 1
        }
        
        if let context = card.managedObjectContext {
            do {
                try context.save()
            } catch {
                print("Ошибка сохранения isLearned: \(error)")
            }
        }
        
        currentIndex += 1
        
        let response = TestModels.CheckAnswerResponse(
            resultMessage: resultMessage,
            correctAnswers: correctAnswers,
            incorrectAnswers: incorrectAnswers,
            totalCards: cards.count,
            isTestCompleted: currentIndex >= cards.count
        )
        presenter?.presentAnswer(response: response)
    }
}
