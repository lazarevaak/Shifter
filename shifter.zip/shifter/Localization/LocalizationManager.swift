import Foundation

final class LocalizationManager {
    static let shared = LocalizationManager()
    
    private var bundle: Bundle?
    private(set) var selectedLanguage: String
    
    private init() {
        // Считываем выбранный язык из UserDefaults, если он существует, иначе используем "en"
        if let savedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") {
            self.selectedLanguage = savedLanguage
        } else {
            self.selectedLanguage = "en"
        }
        updateBundle()
    }
    
    func updateLanguage(to language: String) {
        selectedLanguage = language
        // Сохраняем выбранный язык в UserDefaults
        UserDefaults.standard.set(language, forKey: "AppLanguage")
        updateBundle()
        NotificationCenter.default.post(name: Notification.Name("LanguageDidChange"), object: nil)
    }
    
    private func updateBundle() {
        if let path = Bundle.main.path(forResource: selectedLanguage, ofType: "lproj"),
           let langBundle = Bundle(path: path) {
            bundle = langBundle
        } else {
            bundle = Bundle.main
        }
    }
    
    func localizedString(for key: String, comment: String = "") -> String {
        return bundle?.localizedString(forKey: key, value: nil, table: nil) ?? key
    }
}

extension String {
    var localized: String {
        return LocalizationManager.shared.localizedString(for: self)
    }
}
