import UIKit

// MARK: - Presentation Logic
protocol ConfirmActionPresentationLogic {
    func presentConfirmAction(response: ConfirmActionModels.Confirm.Response)
}

final class ConfirmActionPresenter: ConfirmActionPresentationLogic {
    weak var viewController: ConfirmActionDisplayLogic?
    
    func presentConfirmAction(response: ConfirmActionModels.Confirm.Response) {
        let viewModel: ConfirmActionModels.Confirm.ViewModel
        if response.isValid {
            viewModel = ConfirmActionModels.Confirm.ViewModel(success: true,
                                                              message: "confirm_password_success".localized)
        } else {
            viewModel = ConfirmActionModels.Confirm.ViewModel(success: false,
                                                              message: response.errorMessage ?? "error_default".localized)
        }
        viewController?.displayConfirmAction(viewModel: viewModel)
    }
}
