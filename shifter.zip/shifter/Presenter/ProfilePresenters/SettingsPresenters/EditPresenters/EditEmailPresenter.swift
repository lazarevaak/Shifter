import UIKit

// MARK: - Presentation Logic
protocol EditEmailPresentationLogic {
    func presentUpdateEmail(response: EditEmailModels.UpdateEmail.Response)
}

final class EditEmailPresenter: EditEmailPresentationLogic {
    weak var viewController: EditEmailDisplayLogic?
    
    func presentUpdateEmail(response: EditEmailModels.UpdateEmail.Response) {
        let viewModel: EditEmailModels.UpdateEmail.ViewModel
        if response.success {
            viewModel = EditEmailModels.UpdateEmail.ViewModel(success: true,
                message: "email_update_success".localized)
        } else {
            viewModel = EditEmailModels.UpdateEmail.ViewModel(success: false,
                message: response.errorMessage ?? "error_default".localized)
        }
        viewController?.displayUpdateEmail(viewModel: viewModel)
    }
}
