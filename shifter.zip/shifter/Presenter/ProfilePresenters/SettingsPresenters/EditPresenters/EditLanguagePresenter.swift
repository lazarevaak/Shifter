import Foundation

// MARK: - Presentation Logic
protocol EditLanguagePresentationLogic {
    func presentUpdateLanguage(response: EditLanguageModels.UpdateLanguage.Response)
}

final class EditLanguagePresenter: EditLanguagePresentationLogic {
    weak var viewController: EditLanguageDisplayLogic?
    
    func presentUpdateLanguage(response: EditLanguageModels.UpdateLanguage.Response) {
        let viewModel = EditLanguageModels.UpdateLanguage.ViewModel(success: response.success,
                                                                   message: response.message ?? "")
        viewController?.displayUpdateLanguage(viewModel: viewModel)
    }
}
