import Foundation

// MARK: - Presentation Logic
protocol EditPasswordPresentationLogic {
    func presentUpdatePassword(response: EditPasswordModels.UpdatePassword.Response)
}

final class EditPasswordPresenter: EditPasswordPresentationLogic {
    weak var viewController: EditPasswordDisplayLogic?
    
    func presentUpdatePassword(response: EditPasswordModels.UpdatePassword.Response) {
        let viewModel = EditPasswordModels.UpdatePassword.ViewModel(success: response.success,
                                                                    message: response.message ?? "")
        viewController?.displayUpdatePassword(viewModel: viewModel)
    }
}
