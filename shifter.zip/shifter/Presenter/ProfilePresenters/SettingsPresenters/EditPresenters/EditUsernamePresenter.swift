import Foundation

// MARK: - Presentation Logic
protocol EditUsernamePresentationLogic {
    func presentUpdateUsername(response: EditUsernameModels.UpdateUsername.Response)
}

final class EditUsernamePresenter: EditUsernamePresentationLogic {
    weak var viewController: EditUsernameDisplayLogic?
    
    func presentUpdateUsername(response: EditUsernameModels.UpdateUsername.Response) {
        let viewModel = EditUsernameModels.UpdateUsername.ViewModel(success: response.success,
                                                                    message: response.message ?? "")
        viewController?.displayUpdateUsername(viewModel: viewModel)
    }
}

