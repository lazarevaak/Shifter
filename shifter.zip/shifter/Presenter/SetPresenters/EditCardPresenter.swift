import UIKit

// MARK: - Презентация (Presenter)
protocol EditCardPresentationLogic: AnyObject {
    func presentUpdatedCard(response: EditCard.UpdateCard.Response)
}

class EditCardPresenter: EditCardPresentationLogic {
    weak var viewController: EditCardDisplayLogic?
    
    func presentUpdatedCard(response: EditCard.UpdateCard.Response) {
        // Формируем ViewModel и передаём во ViewController
        let viewModel = EditCard.UpdateCard.ViewModel(card: response.card)
        viewController?.displayUpdatedCard(viewModel: viewModel)
    }
}
