import Foundation

final class SetsPresenter: SetsPresentationLogic {
    weak var viewController: SetsDisplayLogic?
    
    func presentFetchedSets(response: SetsModels.FetchSetsResponse) {
        let viewModels = response.sets.map { set in
            SetsModels.CardSetViewModel(
                name: set.name ?? "untitled".localized,
                progressOfSet: set.progressOfSet, // Используем значение из модели
                id: set.objectID
            )
        }
        let viewModel = SetsModels.FetchSetsViewModel(displayedSets: viewModels)
        viewController?.displayFetchedSets(viewModel: viewModel)
    }
    
    func presentSearchedSets(response: SetsModels.SearchResponse) {
        let viewModels = response.sets.map { set in
            SetsModels.CardSetViewModel(
                name: set.name ?? "untitled".localized,
                progressOfSet: set.progressOfSet,
                id: set.objectID
            )
        }
        let viewModel = SetsModels.FetchSetsViewModel(displayedSets: viewModels)
        viewController?.displayFetchedSets(viewModel: viewModel)
    }
    
    func presentSortedSets(sets: [CardSet]) {
        let viewModels = sets.map { set in
            SetsModels.CardSetViewModel(
                name: set.name ?? "untitled".localized,
                progressOfSet: set.progressOfSet,
                id: set.objectID
            )
        }
        let viewModel = SetsModels.FetchSetsViewModel(displayedSets: viewModels)
        viewController?.displayFetchedSets(viewModel: viewModel)
    }
    
    func presentDeletedSet() {
        // Реализуйте при необходимости уведомление об удалении
    }
}
