import UIKit

protocol TestPresentationLogic: AnyObject {
    func presentTest(response: TestModels.TestResponse)
    func presentAnswer(response: TestModels.CheckAnswerResponse)
}

final class TestPresenter: TestPresentationLogic {
    
    weak var viewController: TestDisplayLogic?
    
    func presentTest(response: TestModels.TestResponse) {
        let viewModel = TestModels.TestViewModel(
            questionText: response.question,
            currentIndexText: "\(response.currentIndex + 1)",
            totalCardsText: "\(response.totalCards)",
            progress: response.progress,
            isTestCompleted: response.isTestCompleted
        )
        viewController?.displayTest(viewModel: viewModel)
    }
    
    func presentAnswer(response: TestModels.CheckAnswerResponse) {
        let viewModel = TestModels.CheckAnswerViewModel(
            alertTitle: response.resultMessage,
            correctAnswers: response.correctAnswers,
            incorrectAnswers: response.incorrectAnswers,
            totalCards: response.totalCards,
            isTestCompleted: response.isTestCompleted
        )
        viewController?.displayAnswer(viewModel: viewModel)
    }
}
