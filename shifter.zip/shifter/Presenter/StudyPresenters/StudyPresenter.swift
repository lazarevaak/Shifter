import UIKit

// MARK: - Презентер

final class StudyPresenter: StudyPresentationLogic {
    weak var viewController: StudyDisplayLogic?
    
    func presentMenuItems(response: StudyModels.FetchMenuItemsResponse) {
        let viewModels = response.menuItems.map { item in
            StudyModels.MenuItemViewModel(id: item.id, iconName: item.iconName, title: item.title)
        }
        let viewModel = StudyModels.FetchMenuItemsViewModel(menuItems: viewModels)
        viewController?.displayMenuItems(viewModel: viewModel)
    }
}
