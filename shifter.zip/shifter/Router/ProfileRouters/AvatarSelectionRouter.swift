import UIKit

// MARK: - Router
final class AvatarSelectionRouter: AvatarSelectionRoutingLogic {
    weak var viewController: UIViewController?
    
    func dismiss() {
        viewController?.dismiss(animated: true)
    }
}

