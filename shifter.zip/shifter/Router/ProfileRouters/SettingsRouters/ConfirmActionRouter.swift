import UIKit

// MARK: - Routing
protocol ConfirmActionRoutingLogic {
    func routeToPreviousScreen()
}

final class ConfirmActionRouter: ConfirmActionRoutingLogic {
    weak var viewController: UIViewController?
    
    func routeToPreviousScreen() {
        viewController?.dismiss(animated: true, completion: nil)
    }
}

