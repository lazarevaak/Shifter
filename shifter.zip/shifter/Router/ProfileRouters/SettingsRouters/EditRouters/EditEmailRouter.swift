import UIKit

// MARK: - Routing
protocol EditEmailRoutingLogic {
    func routeToPreviousScreen()
}

final class EditEmailRouter: EditEmailRoutingLogic {
    weak var viewController: UIViewController?
    
    func routeToPreviousScreen() {
        viewController?.dismiss(animated: true, completion: nil)
    }
}

