import UIKit

// MARK: - Routing
protocol EditLanguageRoutingLogic {
    func routeToPreviousScreen()
}

final class EditLanguageRouter: EditLanguageRoutingLogic {
    weak var viewController: UIViewController?
    
    func routeToPreviousScreen() {
        viewController?.dismiss(animated: true, completion: nil)
    }
}

