import UIKit

// MARK: - Routing
protocol EditPasswordRoutingLogic {
    func routeToPreviousScreen()
}

final class EditPasswordRouter: EditPasswordRoutingLogic {
    weak var viewController: UIViewController?
    
    func routeToPreviousScreen() {
        viewController?.dismiss(animated: true, completion: nil)
    }
}

