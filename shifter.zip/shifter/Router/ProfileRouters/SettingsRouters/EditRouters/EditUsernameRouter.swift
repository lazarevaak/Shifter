import UIKit

// MARK: - Routing
protocol EditUsernameRoutingLogic {
    func routeToPreviousScreen()
}

final class EditUsernameRouter: EditUsernameRoutingLogic {
    weak var viewController: UIViewController?
    
    func routeToPreviousScreen() {
        viewController?.dismiss(animated: true, completion: nil)
    }
}

