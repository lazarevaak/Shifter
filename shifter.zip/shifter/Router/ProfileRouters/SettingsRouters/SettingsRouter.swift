import UIKit

protocol SettingsRoutingLogic: AnyObject {
    func routeToPreviousScreen()
    func routeToSignIn()
}

final class SettingsRouter: SettingsRoutingLogic {
    weak var viewController: UIViewController?
    
    func routeToPreviousScreen() {
        if let navigationController = viewController?.navigationController {
            navigationController.popViewController(animated: true)
        } else {
            viewController?.dismiss(animated: true, completion: nil)
        }
    }
    
    func routeToSignIn() {
        SessionManager.shared.signOut()
        
        let signInVC = SignInViewController()
        let navController = UINavigationController(rootViewController: signInVC)
        navController.modalPresentationStyle = .fullScreen
        
        guard let windowScene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene,
              let window = windowScene.windows.first(where: { $0.isKeyWindow }) else {
            return
        }
        
        window.rootViewController = navController
        window.makeKeyAndVisible()
    }
}
