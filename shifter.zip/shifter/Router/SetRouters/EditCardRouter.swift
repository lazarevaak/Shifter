import UIKit

// MARK: - Routing
protocol EditCardRoutingLogic {
    func routeToPreviousScreen()
}

final class EditCardRouter: EditCardRoutingLogic {
    weak var viewController: UIViewController?
    
    func routeToPreviousScreen() {
        viewController?.dismiss(animated: true, completion: nil)
    }
}

