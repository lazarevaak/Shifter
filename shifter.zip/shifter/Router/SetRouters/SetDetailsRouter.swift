import UIKit

protocol SetDetailsRoutingLogic {
    func dismiss()
}

class SetDetailsRouter: SetDetailsRoutingLogic {
    
    weak var viewController: UIViewController?
    
    func dismiss() {
        viewController?.dismiss(animated: true, completion: nil)
    }
}

