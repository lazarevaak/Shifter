import UIKit

// MARK: - Роутер

final class CardsRouter {
    weak var viewController: UIViewController?
    
    func routeToResults(leftScore: Int, rightScore: Int, progress: Int) {
        let resultsView = ResultsView(frame: viewController?.view.bounds ?? .zero)
        resultsView.configureResults(leftScore: leftScore, rightScore: rightScore, progress: progress)
        resultsView.onDismiss = { [weak self] in
            self?.viewController?.dismiss(animated: true)
        }
        viewController?.view.addSubview(resultsView)
    }
}

