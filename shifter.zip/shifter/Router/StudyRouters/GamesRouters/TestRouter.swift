import UIKit

protocol TestRoutingLogic: AnyObject {
}

final class TestRouter: TestRoutingLogic {
    weak var viewController: UIViewController?
}
