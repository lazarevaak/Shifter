import UIKit
import CoreData
import Compression
import os.log

// MARK: - UIViewController Extension для получения верхнего контроллера
extension UIViewController {
    func topMostViewController() -> UIViewController {
        if let presented = self.presentedViewController {
            return presented.topMostViewController()
        }
        if let nav = self as? UINavigationController, let visible = nav.visibleViewController {
            return visible.topMostViewController()
        }
        if let tab = self as? UITabBarController, let selected = tab.selectedViewController {
            return selected.topMostViewController()
        }
        return self
    }
}

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene,
               willConnectTo session: UISceneSession,
               options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        let window = UIWindow(windowScene: windowScene)
        
        let isUserLoggedIn = UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        let rootVC: UIViewController
        if isUserLoggedIn, let user = SessionManager.shared.currentUser {
            rootVC = ProfileViewController(user: user)
        } else {
            rootVC = SignInViewController()
        }
        
        let navigationController = UINavigationController(rootViewController: rootVC)
        window.rootViewController = navigationController
        window.makeKeyAndVisible()
        self.window = window
        
        if let urlContext = connectionOptions.urlContexts.first {
            handleIncomingURL(urlContext.url)
        }
    }
    
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        guard let urlContext = URLContexts.first else { return }
        handleIncomingURL(urlContext.url)
    }
    
    private func handleIncomingURL(_ url: URL) {
        let logger = OSLog(subsystem: Bundle.main.bundleIdentifier ?? "com.example.myapp", category: "URLHandler")
        os_log("Получен URL: %{public}@", log: logger, type: .debug, url.absoluteString)
        
        if url.scheme == "myapp", url.host == "createSet" {
            guard let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
                  let queryItems = components.queryItems,
                  let dataItem = queryItems.first(where: { $0.name == "d" })?.value,
                  let percentDecodedString = dataItem.removingPercentEncoding,
                  let base64Data = Data(base64Encoded: percentDecodedString),
                  let jsonData = base64Data.decompressed(using: COMPRESSION_ZLIB) else {
                os_log("Не удалось извлечь или декодировать параметр 'd'", log: logger, type: .error)
                return
            }
            
            os_log("Распакованные JSON данные, размер: %{public}d байт", log: logger, type: .debug, jsonData.count)
            
            do {
                if let setData = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                    os_log("Получены данные набора: %{public}@", log: logger, type: .debug, String(describing: setData))
                    
                    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
                    guard let entity = NSEntityDescription.entity(forEntityName: "CardSet", in: context) else {
                        os_log("Ошибка создания сущности CardSet", log: logger, type: .error)
                        return
                    }
                    
                    let cardSet = CardSet(entity: entity, insertInto: context)
                    cardSet.name = setData["n"] as? String
                    cardSet.setDescription = setData["d"] as? String
                    cardSet.textOfSet = setData["t"] as? String
                    
                    if let cardsArray = setData["c"] as? [[String: String]] {
                        for cardDict in cardsArray {
                            guard let cardEntity = NSEntityDescription.entity(forEntityName: "Card", in: context) else { continue }
                            let card = Card(entity: cardEntity, insertInto: context)
                            card.question = cardDict["q"]
                            card.answer = cardDict["a"]
                            cardSet.addToCards(card)
                        }
                    }
                    
                    do {
                        try context.save()
                    } catch {
                        os_log("Ошибка сохранения набора: %{public}@", log: logger, type: .error, error.localizedDescription)
                    }
                    
                    let setVC = SetDetailsViewController(cardSet: cardSet)
                    setVC.isDownloadMode = true
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        if let rootVC = self.window?.rootViewController {
                            let topVC = rootVC.topMostViewController()
                            topVC.present(setVC, animated: true) {
                                os_log("SetDetailsViewController представлен", log: logger, type: .debug)
                            }
                        } else {
                            os_log("Не удалось найти rootViewController", log: logger, type: .error)
                        }
                    }
                }
            } catch {
                os_log("Ошибка парсинга JSON: %{public}@", log: logger, type: .error, error.localizedDescription)
            }
        }
    }
}
