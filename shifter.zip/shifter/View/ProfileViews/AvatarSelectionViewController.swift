import UIKit
import CoreData

// MARK: - Протокол отображения

protocol AvatarSelectionDisplayLogic: AnyObject {
    func displaySaveAvatar(viewModel: AvatarSelection.SaveAvatar.ViewModel)
    func displayAvatarIcons(viewModel: AvatarSelection.FetchAvatarIcons.ViewModel)
}

// MARK: - ViewController

final class AvatarSelectionViewController: UIViewController {
    var interactor: AvatarSelectionBusinessLogic?
    var router: AvatarSelectionRoutingLogic?
    
    // MARK: - UI Элементы
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 8
        layout.minimumLineSpacing = 8
        
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(AvatarCell.self, forCellWithReuseIdentifier: "AvatarCell")
        cv.dataSource = self
        cv.delegate = self
        cv.backgroundColor = .systemBackground
        cv.translatesAutoresizingMaskIntoConstraints = false
        return cv
    }()
    
    private var selectedIndexPath: IndexPath?
    private var selectedImage: UIImage?
    private var icons: [String] = []
    
    var onAvatarSelected: ((UIImage) -> Void)?
    
    // MARK: - Инициализация
    init(user: User, context: NSManagedObjectContext) {
        super.init(nibName: nil, bundle: nil)
        setup(user: user, context: context)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) не используется")
    }
    
    private func setup(user: User, context: NSManagedObjectContext) {
        let interactor = AvatarSelectionInteractor(user: user, context: context)
        let presenter = AvatarSelectionPresenter()
        let router = AvatarSelectionRouter()
        
        self.interactor = interactor
        self.router = router
        interactor.presenter = presenter
        presenter.viewController = self
        router.viewController = self
    }
    
    // MARK: - Жизненный цикл
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupNavigationBar()
        setupCollectionView()
        interactor?.fetchAvatarIcons(request: AvatarSelection.FetchAvatarIcons.Request())
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateLocalizedTexts), name: Notification.Name("LanguageDidChange"), object: nil)
    }
    
    private func setupNavigationBar() {
        let cancelItem = UIBarButtonItem(
            title: "cancel_button_title".localized,
            style: .plain,
            target: self,
            action: #selector(cancelButtonTapped)
        )
        cancelItem.tintColor = .gray
        navigationItem.leftBarButtonItem = cancelItem
        
        let saveItem = UIBarButtonItem(
            title: "save_button_title".localized,
            style: .done,
            target: self,
            action: #selector(saveButtonTapped)
        )
        saveItem.tintColor = ColorsLayoutConstants.basicColor
        navigationItem.rightBarButtonItem = saveItem
        
        let cameraButton = UIButton(type: .system)
        cameraButton.setImage(UIImage(systemName: "camera"), for: .normal)
        cameraButton.addTarget(self, action: #selector(cameraButtonTapped), for: .touchUpInside)
        cameraButton.tintColor = .gray
        
        let galleryButton = UIButton(type: .system)
        galleryButton.setImage(UIImage(systemName: "photo"), for: .normal)
        galleryButton.addTarget(self, action: #selector(galleryButtonTapped), for: .touchUpInside)
        galleryButton.tintColor = .gray
        
        let stackView = UIStackView(arrangedSubviews: [cameraButton, galleryButton])
        stackView.axis = .horizontal
        stackView.spacing = 24
        navigationItem.titleView = stackView
    }
    
    private func setupCollectionView() {
        view.addSubview(collectionView)
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    // MARK: - Действия
    @objc private func cancelButtonTapped() {
        router?.dismiss()
    }
    
    @objc private func saveButtonTapped() {
        let request = AvatarSelection.SaveAvatar.Request(
            selectedImage: selectedImage,
            selectedIconIndex: selectedIndexPath?.row
        )
        interactor?.saveAvatar(request: request)
    }
    
    @objc private func cameraButtonTapped() {
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            print("Камера недоступна на этом устройстве/эмуляторе")
            return
        }
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .camera
        present(picker, animated: true)
    }
    
    @objc private func galleryButtonTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }
    
    @objc private func updateLocalizedTexts() {
        navigationItem.leftBarButtonItem?.title = "cancel_button_title".localized
        navigationItem.rightBarButtonItem?.title = "save_button_title".localized
    }
}

// MARK: - Отображение (Display Logic)
extension AvatarSelectionViewController: AvatarSelectionDisplayLogic {
    func displaySaveAvatar(viewModel: AvatarSelection.SaveAvatar.ViewModel) {
        print(viewModel.displayMessage)
        if viewModel.displayMessage == "Аватар успешно сохранён" {
            if let image = selectedImage {
                onAvatarSelected?(image)
            } else if let indexPath = selectedIndexPath,
                      let iconName = icons[safe: indexPath.row],
                      let image = UIImage(named: iconName) {
                onAvatarSelected?(image)
            }
            router?.dismiss()
        }
    }
    
    func displayAvatarIcons(viewModel: AvatarSelection.FetchAvatarIcons.ViewModel) {
        self.icons = viewModel.icons
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
extension AvatarSelectionViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return icons.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "AvatarCell",
            for: indexPath) as? AvatarCell else {
            return UICollectionViewCell()
        }
        let iconName = icons[indexPath.row]
        cell.configure(with: iconName)
        let isSelected = (indexPath == selectedIndexPath)
        cell.contentView.layer.borderColor = isSelected ? UIColor.systemBlue.cgColor : UIColor.clear.cgColor
        cell.contentView.layer.borderWidth = isSelected ? 2 : 0
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedImage = nil
        selectedIndexPath = indexPath
        collectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let totalSpacing: CGFloat = 16 * 2 + 8 * 2
        let width = (collectionView.frame.width - totalSpacing) / 3
        return CGSize(width: width, height: width)
    }
}

// MARK: - UIImagePickerControllerDelegate, UINavigationControllerDelegate
extension AvatarSelectionViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let pickedImage = info[.originalImage] as? UIImage else { return }
        selectedImage = pickedImage
        selectedIndexPath = nil
        collectionView.reloadData()
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}

// MARK: - AvatarCell
final class AvatarCell: UICollectionViewCell {
    private let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)
        contentView.layer.cornerRadius = 8
        contentView.clipsToBounds = true
        
        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            imageView.widthAnchor.constraint(equalTo: contentView.widthAnchor, multiplier: 0.8),
            imageView.heightAnchor.constraint(equalTo: contentView.heightAnchor, multiplier: 0.8)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) не используется")
    }
    
    func configure(with iconName: String) {
        imageView.image = UIImage(named: iconName)
    }
}

// MARK: - Array Extension для безопасного доступа
extension Array {
    subscript(safe index: Int) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
