import UIKit
import CoreData

final class ProfileViewController: UIViewController, ProfileDisplayLogic {
    
    // MARK: - Clean Swift Components
    private var interactor: ProfileBusinessLogic?
    private var router: ProfileRoutingLogic?
    
    // MARK: - Новая линия сверху
    private let topDividerView: UIView = {
        let view = UIView()
        view.backgroundColor = .lightGray
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let profileImageView: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(systemName: "person.circle")
        iv.tintColor = .label
        iv.contentMode = .scaleAspectFill
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.clipsToBounds = true
        iv.layer.cornerRadius = 60
        iv.isUserInteractionEnabled = true
        return iv
    }()
    
    private let textFieldUnderline: UIView = {
        let view = UIView()
        view.backgroundColor = ColorsLayoutConstants.linesColor
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let userNameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let settingsButton: UIButton = {
        let button = UIButton(type: .system);
        button.setTitle("your_settings_title".localized, for: .normal)
        button.setTitleColor(.systemBackground, for: .normal)
        button.backgroundColor = .systemGray4
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let dividerSettingsCalendar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.secondaryLabel
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let tabBarView: UIView = {
        let view = UIView()
        view.backgroundColor = .systemBackground
        view.layer.borderColor = UIColor.secondaryLabel.cgColor
        view.layer.borderWidth = 0.5
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let documentButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "doc.text"), for: .normal)
        button.tintColor = .label
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let addButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "plus.circle"), for: .normal)
        button.tintColor = .label
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let profileButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "person.circle"), for: .normal)
        button.tintColor = .label
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let calendarView: CalendarViewController = {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let cv = CalendarViewController(context: context)
        return cv
    }()
    
    // MARK: - Модель пользователя (Core Data объект)
    private var user: User
    
    // MARK: - Инициализация
    init(user: User) {
        self.user = user
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) не реализован")
    }
    
    // MARK: - Жизненный цикл
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        navigationItem.hidesBackButton = true
        
        view.addSubview(topDividerView)
        view.addSubview(profileImageView)
        view.addSubview(userNameLabel)
        view.addSubview(textFieldUnderline)
        view.addSubview(settingsButton)
        view.addSubview(dividerSettingsCalendar)
        view.addSubview(calendarView)
        view.addSubview(tabBarView)
        
        let stackView = UIStackView(arrangedSubviews: [documentButton, addButton, profileButton])
        stackView.axis = .horizontal
        stackView.distribution = .equalSpacing
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        tabBarView.addSubview(stackView)
        
        settingsButton.addTarget(self, action: #selector(settingsTapped), for: .touchUpInside)
        documentButton.addTarget(self, action: #selector(openSetsScreen), for: .touchUpInside)
        addButton.addTarget(self, action: #selector(openCreateSetScreen), for: .touchUpInside)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(avatarTapped))
        profileImageView.addGestureRecognizer(tapGesture)
        
        setupConstraints(stackView)
        setupModule()
        
        interactor?.fetchProfile(request: Profile.Request())
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateLocalizedTexts), name: Notification.Name("LanguageDidChange"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        interactor?.fetchProfile(request: Profile.Request())
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func setupConstraints(_ stackView: UIStackView) {
        NSLayoutConstraint.activate([
            topDividerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            topDividerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topDividerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topDividerView.heightAnchor.constraint(equalToConstant: 0.5),
            
            profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileImageView.topAnchor.constraint(equalTo: topDividerView.bottomAnchor, constant: 30),
            profileImageView.widthAnchor.constraint(equalToConstant: 120),
            profileImageView.heightAnchor.constraint(equalToConstant: 120),
            
            userNameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            userNameLabel.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 16),
            
            textFieldUnderline.topAnchor.constraint(equalTo: userNameLabel.bottomAnchor, constant: 16),
            textFieldUnderline.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textFieldUnderline.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textFieldUnderline.heightAnchor.constraint(equalToConstant: 0.5),
            
            settingsButton.topAnchor.constraint(equalTo: textFieldUnderline.bottomAnchor, constant: 16),
            settingsButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            settingsButton.widthAnchor.constraint(equalToConstant: 360),
            settingsButton.heightAnchor.constraint(equalToConstant: 50),
            
            dividerSettingsCalendar.topAnchor.constraint(equalTo: settingsButton.bottomAnchor, constant: 16),
            dividerSettingsCalendar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            dividerSettingsCalendar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            dividerSettingsCalendar.heightAnchor.constraint(equalToConstant: 0.5),
            
            calendarView.topAnchor.constraint(equalTo: dividerSettingsCalendar.bottomAnchor, constant: 16),
            calendarView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            calendarView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            calendarView.heightAnchor.constraint(equalToConstant: 300),
            
            tabBarView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            tabBarView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tabBarView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tabBarView.heightAnchor.constraint(equalToConstant: 60),
            
            stackView.leadingAnchor.constraint(equalTo: tabBarView.leadingAnchor, constant: 50),
            stackView.trailingAnchor.constraint(equalTo: tabBarView.trailingAnchor, constant: -50),
            stackView.centerYAnchor.constraint(equalTo: tabBarView.centerYAnchor)
        ])
    }
    
    private func setupModule() {
        let interactor = ProfileInteractor(user: user)
        let presenter = ProfilePresenter()
        let router = ProfileRouter()
        self.interactor = interactor
        self.router = router
        interactor.presenter = presenter
        presenter.viewController = self
        router.viewController = self
    }
    
    // MARK: - ProfileDisplayLogic
    func displayProfile(viewModel: Profile.ViewModel) {
        userNameLabel.text = viewModel.userName
        if let data = user.avatarData, let image = UIImage(data: data) {
            profileImageView.image = image
        }
    }
    
    // MARK: - Действия
    @objc private func settingsTapped() {
        router?.routeToSettings(with: user)
    }
    
    @objc private func openSetsScreen() {
        router?.routeToSetsScreen(with: user)
    }
    
    @objc private func openCreateSetScreen() {
        router?.routeToCreateSet(with: user)
    }
    
    @objc private func avatarTapped() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let avatarVC = AvatarSelectionViewController(user: user, context: context)
        avatarVC.onAvatarSelected = { [weak self] selectedImage in
            self?.profileImageView.image = selectedImage
        }
        let navController = UINavigationController(rootViewController: avatarVC)
        navController.modalPresentationStyle = .pageSheet
        present(navController, animated: true, completion: nil)
    }
    
    // MARK: - Метод обновления локализации
    @objc private func updateLocalizedTexts() {
        settingsButton.setTitle("your_settings_title".localized, for: .normal)
    }
}
