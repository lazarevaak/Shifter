import UIKit

// MARK: - Display Logic
protocol ConfirmActionDisplayLogic: AnyObject {
    func displayConfirmAction(viewModel: ConfirmActionModels.Confirm.ViewModel)
}

final class ConfirmActionViewController: UIViewController, ConfirmActionDisplayLogic {
    
    weak var delegate: ConfirmActionDelegate?
    
    var interactor: ConfirmActionBusinessLogic?
    var router: ConfirmActionRoutingLogic?
    
    private let user: User
    
    // MARK: - UI Elements
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "confirm_action_title".localized
        label.font = UIFont.boldSystemFont(ofSize: 18)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var passwordTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "enter_current_password".localized
        tf.borderStyle = .roundedRect
        tf.isSecureTextEntry = true
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    private lazy var confirmButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("confirm_button_title".localized, for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = ColorsLayoutConstants.basicColor
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(confirmTapped), for: .touchUpInside)
        return button
    }()
    
    private lazy var cancelButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("cancel_button_title".localized, for: .normal)
        button.tintColor = .lightGray
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(cancelTapped), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Initialization
    init(user: User) {
        self.user = user
        super.init(nibName: nil, bundle: nil)
        setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup VIP Cycle
    private func setup() {
        let interactor = ConfirmActionInteractor(user: user)
        let presenter = ConfirmActionPresenter()
        let router = ConfirmActionRouter()
        self.interactor = interactor
        self.router = router
        interactor.presenter = presenter
        presenter.viewController = self
        router.viewController = self
    }
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupLayout()
    }
    
    private func setupLayout() {
        view.addSubview(titleLabel)
        view.addSubview(passwordTextField)
        view.addSubview(confirmButton)
        view.addSubview(cancelButton)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            passwordTextField.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            passwordTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            passwordTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            confirmButton.topAnchor.constraint(equalTo: passwordTextField.bottomAnchor, constant: 20),
            confirmButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            confirmButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            confirmButton.heightAnchor.constraint(equalToConstant: 44),
            
            cancelButton.topAnchor.constraint(equalTo: confirmButton.bottomAnchor, constant: 10),
            cancelButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            cancelButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            cancelButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }
    
    // MARK: - Actions
    @objc private func confirmTapped() {
        let enteredPassword = passwordTextField.text ?? ""
        let request = ConfirmActionModels.Confirm.Request(password: enteredPassword)
        interactor?.confirmAction(request: request)
    }
    
    @objc private func cancelTapped() {
        router?.routeToPreviousScreen()
    }
    
    // MARK: - ConfirmActionDisplayLogic
    func displayConfirmAction(viewModel: ConfirmActionModels.Confirm.ViewModel) {
        if viewModel.success {
            delegate?.didConfirmAction(withPassword: passwordTextField.text ?? "")
            router?.routeToPreviousScreen()
        } else {
            let alert = UIAlertController(
                title: "error_alert_title".localized,
                message: viewModel.message,
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(
                title: "ok_button_title".localized,
                style: .default)
            )
            present(alert, animated: true)
        }
    }
}
