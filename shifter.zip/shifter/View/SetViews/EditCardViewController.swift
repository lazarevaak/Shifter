import UIKit
import CoreData
import OSLog
import Foundation

// MARK: - Протокол отображения (View)
protocol EditCardDisplayLogic: AnyObject {
    func displayUpdatedCard(viewModel: EditCard.UpdateCard.ViewModel)
}

// MARK: - ViewController
final class EditCardViewController: UIViewController, EditCardDisplayLogic {
    
    var interactor: EditCardBusinessLogic?
    var router: EditCardRoutingLogic?
    
    private var card: Card
    
    // Текстовое поле для вопроса
    private lazy var questionTextView: UITextView = {
        let tv = UITextView()
        tv.text = "question_label".localized
        tv.font = UIFont.systemFont(ofSize: 16)
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1
        tv.layer.cornerRadius = 8
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()
    
    // Текстовое поле для ответа
    private lazy var answerTextView: UITextView = {
        let tv = UITextView()
        tv.text = "answer_label".localized
        tv.font = UIFont.systemFont(ofSize: 16)
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1
        tv.layer.cornerRadius = 8
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()
    
    // Кнопка «Сохранить»
    private let saveButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("save_button_title".localized, for: .normal)
        button.backgroundColor = .red
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    // MARK: - Инициализация
    init(card: Card) {
        self.card = card
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) not implemented")
    }
    
    // MARK: - Жизненный цикл
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setup()
        setupLayout()
        setupActions()
        populateFields()
    }
    
    private func setup() {
        // Передаём объект card в Interactor
        let interactor = EditCardInteractor(card: card)
        let presenter = EditCardPresenter()
        let router = EditCardRouter()
        
        self.interactor = interactor
        self.router = router
        
        interactor.presenter = presenter
        presenter.viewController = self
        router.viewController = self
    }
    
    private func setupLayout() {
        view.addSubview(questionTextView)
        view.addSubview(answerTextView)
        view.addSubview(saveButton)
        
        NSLayoutConstraint.activate([
            questionTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            questionTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            questionTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            questionTextView.heightAnchor.constraint(equalToConstant: 80),
            
            answerTextView.topAnchor.constraint(equalTo: questionTextView.bottomAnchor, constant: 20),
            answerTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            answerTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            answerTextView.heightAnchor.constraint(equalToConstant: 80),
            
            saveButton.topAnchor.constraint(equalTo: answerTextView.bottomAnchor, constant: 20),
            saveButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            saveButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            saveButton.heightAnchor.constraint(equalToConstant: 44),
        ])
    }
    
    private func setupActions() {
        saveButton.addTarget(self, action: #selector(saveTapped), for: .touchUpInside)
    }
    
    private func populateFields() {
        questionTextView.text = card.question
        answerTextView.text = card.answer
    }
    
    // MARK: - Действия пользователя
    @objc private func saveTapped() {
        let newQuestion = questionTextView.text ?? ""
        let newAnswer = answerTextView.text ?? ""
        // Используем имена параметров, соответствующие определению структуры запроса
        let request = EditCard.UpdateCard.Request(
            question: newQuestion,
            answer: newAnswer
        )
        interactor?.updateCard(request: request)
    }
    
    // MARK: - EditCardDisplayLogic
    func displayUpdatedCard(viewModel: EditCard.UpdateCard.ViewModel) {
        // После успешного обновления карточки выполняем навигацию назад
        router?.routeToPreviousScreen()
    }
}
