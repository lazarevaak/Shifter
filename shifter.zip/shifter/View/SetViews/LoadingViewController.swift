import UIKit

final class LoadingViewController: UIViewController {
    
    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.color = .systemRed
        indicator.startAnimating()
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()
    
    private let loadingLabel: UILabel = {
        let label = UILabel()
        label.text = "creatingyourset_label".localized
        label.textAlignment = .center
        label.textColor = .systemRed
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let okButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("OK", for: .normal)
        button.tintColor = .white
        button.backgroundColor = .systemRed
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .bold)
        button.isHidden = true
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    var onOKTapped: (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.lightGray.withAlphaComponent(0.4)
        setupLayout()
        
        okButton.addTarget(self, action: #selector(okTapped), for: .touchUpInside)
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateLocalizedTexts), name: Notification.Name("LanguageDidChange"), object: nil)
    }
    
    private func setupLayout() {
        view.addSubview(containerView)
        containerView.addSubview(activityIndicator)
        containerView.addSubview(loadingLabel)
        containerView.addSubview(okButton)
        
        NSLayoutConstraint.activate([
            containerView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            containerView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            containerView.widthAnchor.constraint(equalToConstant: 360),
            containerView.heightAnchor.constraint(equalToConstant: 232),
            
            activityIndicator.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            activityIndicator.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 60),
            
            loadingLabel.topAnchor.constraint(equalTo: activityIndicator.bottomAnchor, constant: 16),
            loadingLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 8),
            loadingLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -8),
            
            okButton.topAnchor.constraint(equalTo: loadingLabel.bottomAnchor, constant: 24),
            okButton.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            okButton.widthAnchor.constraint(equalToConstant: 200),
            okButton.heightAnchor.constraint(equalToConstant: 48),
            okButton.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -24)

        ])
    }
    
    func showResult(message: String, isSuccess: Bool, onOK: @escaping () -> Void) {
        activityIndicator.stopAnimating()
        loadingLabel.text = message
        okButton.isHidden = false
        self.onOKTapped = onOK
    }
    
    @objc private func okTapped() {
        dismiss(animated: false) {
            self.onOKTapped?()
        }
    }
    
    @objc private func updateLocalizedTexts() {
        loadingLabel.text = "creatingyourset_label".localized
    }
}
