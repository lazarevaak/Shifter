import UIKit
import CoreData

final class SetsViewController: UIViewController {
    
    var interactor: SetsBusinessLogic?
    var router: SetsRouter?
    
    private var displayedSets: [SetsModels.CardSetViewModel] = []
    
    // MARK: - UI Elements
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "sets_label".localized
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let searchBar: UISearchBar = {
        let sb = UISearchBar()
        sb.placeholder = "search_label".localized
        sb.translatesAutoresizingMaskIntoConstraints = false
        return sb
    }()
    
    private let sortAscButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "arrow.up.circle")?
            .withTintColor(ColorsLayoutConstants.basicColor, renderingMode: .alwaysOriginal)
        button.setImage(image, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let sortDescButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "arrow.down.circle")?
            .withTintColor(ColorsLayoutConstants.basicColor, renderingMode: .alwaysOriginal)
        button.setImage(image, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        sv.showsVerticalScrollIndicator = false
        sv.showsHorizontalScrollIndicator = false
        return sv
    }()
    
    private let setsStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    private let backButton: UIButton = {
        let button = UIButton(type: .system)
        let image = UIImage(systemName: "arrow.left")?
            .withRenderingMode(.alwaysOriginal)
            .withTintColor(ColorsLayoutConstants.basicColor)
        button.setImage(image, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    // MARK: - Инициализация
    init(currentUser: User) {
        super.init(nibName: nil, bundle: nil)
        let interactor = SetsInteractor(currentUser: currentUser)
        let presenter = SetsPresenter()
        let router = SetsRouter()
        self.interactor = interactor
        self.router = router
        interactor.presenter = presenter
        presenter.viewController = self
        router.viewController = self
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) not implemented")
    }
    
    // MARK: - Жизненный цикл
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ColorsLayoutConstants.buttonTextbackgroundColor
        setupLayout()
        
        backButton.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
        searchBar.delegate = self
        sortAscButton.addTarget(self, action: #selector(sortAscendingTapped), for: .touchUpInside)
        sortDescButton.addTarget(self, action: #selector(sortDescendingTapped), for: .touchUpInside)
        
        fetchSets()
        
        // Подписка на уведомление смены языка для мгновенного обновления UI
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(updateLocalizedTexts),
                                               name: Notification.Name("LanguageDidChange"),
                                               object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchSets()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Layout Setup
    private func setupLayout() {
        view.addSubview(titleLabel)
        view.addSubview(backButton)
        
        let searchAndSortStack = UIStackView(arrangedSubviews: [searchBar, sortAscButton, sortDescButton])
        searchAndSortStack.axis = .horizontal
        searchAndSortStack.spacing = 8
        searchAndSortStack.alignment = .center
        searchAndSortStack.distribution = .fill
        searchAndSortStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchAndSortStack)
        
        view.addSubview(scrollView)
        scrollView.addSubview(setsStackView)
        
        NSLayoutConstraint.activate([
            backButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            backButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            searchAndSortStack.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            searchAndSortStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            searchAndSortStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            scrollView.topAnchor.constraint(equalTo: searchAndSortStack.bottomAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            
            setsStackView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            setsStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            setsStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            setsStackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            setsStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])
    }
    
    // MARK: - Interactor Calls
    private func fetchSets() {
        interactor?.fetchSets(request: SetsModels.FetchSetsRequest())
    }
    
    private func performSearch(query: String) {
        let request = SetsModels.SearchRequest(query: query)
        interactor?.searchSets(request: request)
    }
    
    @objc private func sortAscendingTapped() {
        let request = SetsModels.SortRequest(order: .ascending)
        interactor?.sortSets(request: request)
    }
    
    @objc private func sortDescendingTapped() {
        let request = SetsModels.SortRequest(order: .descending)
        interactor?.sortSets(request: request)
    }
    
    @objc private func backTapped() {
        let transition = CATransition()
        transition.duration = 0.5
        transition.type = .reveal
        transition.subtype = .fromLeft
        view.window?.layer.add(transition, forKey: kCATransition)
        dismiss(animated: false, completion: nil)
    }
    
    // MARK: - Метод обновления локализации (моментальное обновление)
    @objc private func updateLocalizedTexts() {
        titleLabel.text = "sets_label".localized
        searchBar.placeholder = "search_label".localized
        // Если у вас есть другие элементы с текстом, обновите их здесь:
        // Например, кнопки сортировки, backButton, и т.д.
    }
    
    // MARK: - Отображение данных
    private func displaySets(_ sets: [SetsModels.CardSetViewModel]) {
        // Удаляем все предыдущие сабвью из стека
        setsStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        self.displayedSets = sets
        
        // Для каждого набора создаем кнопку с изменяемым фоном в зависимости от progressOfSet
        for (index, setVM) in sets.enumerated() {
            let button = UIButton(type: .system)
            button.setTitle(setVM.name, for: .normal)
            // Определяем цвет фона по проценту выполнения (progressOfSet - значение от 0 до 100)
            let progress = setVM.progressOfSet
            let bgColor: UIColor
            if progress < 33 {
                bgColor = UIColor.lightGray
            } else if progress < 66 {
                bgColor = UIColor.gray
            } else {
                bgColor = UIColor.darkGray
            }
            button.backgroundColor = bgColor
            button.setTitleColor(ColorsLayoutConstants.buttonTextbackgroundColor, for: .normal)
            button.layer.cornerRadius = 8
            button.heightAnchor.constraint(equalToConstant: 48).isActive = true
            button.tag = index
            button.addTarget(self, action: #selector(openSetDetails(_:)), for: .touchUpInside)
            
            // Добавляем долгий жест для удаления
            let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
            button.addGestureRecognizer(longPress)
            
            setsStackView.addArrangedSubview(button)
        }
    }
}

// MARK: - UISearchBarDelegate
extension SetsViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        performSearch(query: searchText)
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
}

// MARK: - Действия пользователя
extension SetsViewController {
    @objc private func openSetDetails(_ sender: UIButton) {
        guard sender.tag < displayedSets.count else { return }
        if let setsInteractor = interactor as? SetsInteractor,
           sender.tag < setsInteractor.availableSets.count {
            let selectedSet = setsInteractor.availableSets[sender.tag]
            router?.routeToSetDetails(set: selectedSet)
        }
    }
    
    @objc private func handleLongPress(_ gesture: UILongPressGestureRecognizer) {
        guard gesture.state == .began,
              let button = gesture.view as? UIButton,
              button.tag < displayedSets.count else { return }
        
        if let setsInteractor = interactor as? SetsInteractor,
           button.tag < setsInteractor.availableSets.count {
            let setToDelete = setsInteractor.availableSets[button.tag]
            let alert = UIAlertController(title: "delete_set_title".localized,
                                          message: "delete_set_message".localizedWithArgs(setToDelete.name ?? "Untitled"),
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "logout_cancel".localized, style: .cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "delete_label".localized, style: .destructive, handler: { [weak self] _ in
                let request = SetsModels.DeleteRequest(set: setToDelete)
                self?.interactor?.deleteSet(request: request)
                self?.fetchSets()
            }))
            present(alert, animated: true)
        }
    }
}

// MARK: - SetsDisplayLogic
extension SetsViewController: SetsDisplayLogic {
    func displayFetchedSets(viewModel: SetsModels.FetchSetsViewModel) {
        DispatchQueue.main.async { [weak self] in
            self?.displaySets(viewModel.displayedSets)
        }
    }
    
    func displayError(message: String) {
        // Реализуйте отображение ошибки, если необходимо
    }
}

// MARK: - Дополнительные методы для локализации формата с аргументами
extension String {
    /// Позволяет подставлять аргументы в локализованную строку.
    /// Пример: "delete_set_message".localizedWithArgs("SetName")
    func localizedWithArgs(_ args: CVarArg...) -> String {
        let localizedString = self.localized
        return String(format: localizedString, arguments: args)
    }
}
