import UIKit

final class AnswerReviewViewController: UIViewController {

    // MARK: - Свойства
    var onNext: (() -> Void)?

    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let questionLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 22, weight: .medium)
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let answerLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 20, weight: .regular)
        label.numberOfLines = 0
        label.textAlignment = .center
        label.textColor = .gray
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let correctnessLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let nextButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Next", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = ColorsLayoutConstants.basicColor
        button.layer.cornerRadius = 12
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    // MARK: - Жизненный цикл
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        setupLayout()
        nextButton.addTarget(self, action: #selector(nextTapped), for: .touchUpInside)
    }
    
    // MARK: - Layout
    private func setupLayout() {
        view.addSubview(containerView)
        
        containerView.addSubview(questionLabel)
        containerView.addSubview(answerLabel)
        containerView.addSubview(correctnessLabel)
        containerView.addSubview(nextButton)
        
        NSLayoutConstraint.activate([
            containerView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            containerView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            containerView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            
            questionLabel.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
            questionLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            questionLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            
            answerLabel.topAnchor.constraint(equalTo: questionLabel.bottomAnchor, constant: 20),
            answerLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            answerLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            
            correctnessLabel.topAnchor.constraint(equalTo: answerLabel.bottomAnchor, constant: 20),
            correctnessLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            correctnessLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            
            nextButton.topAnchor.constraint(equalTo: correctnessLabel.bottomAnchor, constant: 30),
            nextButton.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            nextButton.widthAnchor.constraint(equalToConstant: 200),
            nextButton.heightAnchor.constraint(equalToConstant: 50),
            nextButton.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -20)
        ])
    }
    
    // MARK: - Конфигурация
    func configure(with viewModel: TestModels.CheckAnswerViewModel) {
        questionLabel.text = viewModel.alertTitle
        answerLabel.text = "Correct: \(viewModel.correctAnswers)\nIncorrect: \(viewModel.incorrectAnswers)\nTotal: \(viewModel.totalCards)"
        correctnessLabel.text = viewModel.isTestCompleted ? "Test Completed" : ""
    }
    
    @objc private func nextTapped() {
        dismiss(animated: true) {
            self.onNext?()
        }
    }
}
