import UIKit

final class ResultsView: UIView {
    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "allcardspassed_label".localized
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.tintColor = ColorsLayoutConstants.linesColor
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let resultsLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let dismissButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("OK".localized, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        button.tintColor = .white
        button.backgroundColor = ColorsLayoutConstants.basicColor
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    var onDismiss: (() -> Void)?
    
    // Сохраняем текущие значения для обновления локализации
    private var currentLeftScore: Int = 0
    private var currentRightScore: Int = 0
    private var currentProgress: Int = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
        // Добавляем наблюдатель за изменением языка
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(updateLocalizedTexts),
                                               name: Notification.Name("LanguageDidChange"),
                                               object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) не реализован")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: Notification.Name("LanguageDidChange"), object: nil)
    }
    
    private func setupView() {
        backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        addSubview(containerView)
        containerView.addSubview(titleLabel)
        containerView.addSubview(resultsLabel)
        containerView.addSubview(dismissButton)
        
        dismissButton.addTarget(self, action: #selector(dismissTapped), for: .touchUpInside)
        
        NSLayoutConstraint.activate([
            containerView.centerYAnchor.constraint(equalTo: centerYAnchor),
            containerView.centerXAnchor.constraint(equalTo: centerXAnchor),
            containerView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.79),
            containerView.heightAnchor.constraint(equalToConstant: 520),
            
            titleLabel.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 80),
            titleLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            
            resultsLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 80),
            resultsLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            resultsLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            
            dismissButton.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -48),
            dismissButton.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            dismissButton.widthAnchor.constraint(equalToConstant: 240),
            dismissButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    /// Обновляем текст результатов и сохраняем текущее состояние
    func configureResults(leftScore: Int, rightScore: Int, progress: Int) {
        currentLeftScore = leftScore
        currentRightScore = rightScore
        currentProgress = progress
        
        resultsLabel.text = """
        \("Unstudied:".localized) \(leftScore)
        
        
        \("Studied:".localized) \(rightScore)
        
        
        \("Progress:".localized) \(progress)%
        """
    }
    
    @objc private func dismissTapped() {
        UIView.transition(with: containerView, duration: 0.6, options: [.transitionFlipFromLeft], animations: {
            self.containerView.alpha = 0.0
        }) { _ in
            self.onDismiss?()
        }
    }
    
    func presentResults(from parent: UIView, leftScore: Int, rightScore: Int, progress: Int) {
        titleLabel.text = "allcardslearned_label".localized
        configureResults(leftScore: leftScore, rightScore: rightScore, progress: progress)
        
        parent.addSubview(self)
        self.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            self.topAnchor.constraint(equalTo: parent.topAnchor),
            self.bottomAnchor.constraint(equalTo: parent.bottomAnchor),
            self.leadingAnchor.constraint(equalTo: parent.leadingAnchor),
            self.trailingAnchor.constraint(equalTo: parent.trailingAnchor)
        ])
    }
    
    /// Метод, вызываемый при изменении языка – мгновенно обновляет локализуемые тексты
    @objc private func updateLocalizedTexts() {
        titleLabel.text = "allcardslearned_label".localized
        dismissButton.setTitle("OK".localized, for: .normal)
        // Обновляем результаты с уже сохранёнными значениями
        configureResults(leftScore: currentLeftScore, rightScore: currentRightScore, progress: currentProgress)
    }
}
